// next.config.mjs
const nextConfig = {

  images: {
    unoptimized: true,
  },
};

export default nextConfig;