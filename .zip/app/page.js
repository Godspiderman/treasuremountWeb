
import Homepage from './pages/Home/page'

const page = () => {
  return (
    <>

    <Homepage/>
    </>
  )
}

export default page