"use client";
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useSearchParams } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { startLoading, stopLoading } from "@/app/redux/slices/loadingSlice";

const PlaceOrder = () => {
  const dispatch = useDispatch();
  //form data
  const userId = useSelector((state) => state.auth.user?.userId || null);

  const [formData, setFormData] = useState({
    fullName: "",
    userId: userId,
    phoneNumber: "",
    addressLine1: "",
    addressLine2: "",
    city: "",
    postalCode: "",
    countryId: "",
    stateId: "",
    createDate: "",
    updateDate: "",
    defaultAddress: true,
  });

  const [errors, setErrors] = useState({});
  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [isFormVisible, setIsFormVisible] = useState(false);
  useEffect(() => {
    const currentDate = new Date();
    const futureDate = new Date(currentDate);
    futureDate.setDate(currentDate.getDate() + 10);

    setFormData((prev) => ({
      ...prev,
      createDate: currentDate.toISOString(),
      updateDate: futureDate.toISOString(),
    }));
  }, []);

  // Fetch countries on component mount
  useEffect(() => {
    const fetchCountries = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8080/api/public/country/getAll"
        );
        setCountries(response.data);
      } catch (error) {
        console.error("Error fetching countries:", error);
      }
    };

    fetchCountries();
  }, []);

  // Fetch states based on selected country
  useEffect(() => {
    if (formData.countryId) {
      const fetchStates = async () => {
        try {
          const response = await axios.get(
            "http://localhost:8080/api/public/state/getAll"
          );
          const filteredStates = response.data.filter(
            (state) => state.countryId === parseInt(formData.countryId)
          );
          setStates(filteredStates);
        } catch (error) {
          console.error("Error fetching states:", error);
        }
      };

      fetchStates();
    } else {
      setStates([]);
    }
  }, [formData.countryId]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "phoneNumber" && !/^\d*$/.test(value)) {
      return; // Ignore non-numeric input
    }

    setFormData({ ...formData, [name]: value });

    setErrors({ ...errors, [name]: "" });
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.fullName) newErrors.fullName = "Full Name is required";
    if (!formData.phoneNumber || formData.phoneNumber.length !== 10) {
      newErrors.phoneNumber = "Phone number must be 10 digits";
    }
    if (!formData.addressLine1)
      newErrors.addressLine1 = "Address Line 1 is required";
    if (!formData.city) newErrors.city = "City is required";
    if (!formData.postalCode) newErrors.postalCode = "Postal Code is required";
    if (!formData.countryId) newErrors.countryId = "Country is required";
    if (!formData.stateId) newErrors.stateId = "State is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }
    dispatch(startLoading());
    console.log(formData);

    try {
      const response = await axios.post(
        "http://localhost:8080/api/public/shippingAddress/add",
        formData
      );
      alert("Address Added successfully!");
      console.log(response.data);

      const currentDate = new Date();
      const futureDate = new Date(currentDate);
      futureDate.setDate(currentDate.getDate() + 10);

      setFormData({
        fullName: "",
        userId: userId,
        phoneNumber: "",
        addressLine1: "",
        addressLine2: "",
        city: "",
        postalCode: "",
        countryId: "",
        stateId: "",
        createDate: currentDate.toISOString(),
        updateDate: futureDate.toISOString(),
        defaultAddress: true,
      });
      setErrors({});
      fetchAddresses();
      setIsFormVisible(false);
    } catch (error) {
      console.error("Error placing the order:", error);
      alert("Failed to place the order.");
    } finally {
      dispatch(stopLoading());
    }
  };

  const handleCancel = () => {
    const currentDate = new Date();
    const futureDate = new Date(currentDate);
    futureDate.setDate(currentDate.getDate() + 10);

    setFormData({
      fullName: "",
      userId: 0,
      phoneNumber: "",
      addressLine1: "",
      addressLine2: "",
      city: "",
      postalCode: "",
      countryId: "",
      stateId: "",
      createDate: currentDate.toISOString(),
      updateDate: futureDate.toISOString(),
      defaultAddress: true,
    });
    setErrors({});
    setIsFormVisible(false);
  };


  const [addresses, setAddresses] = useState([]);
  const [selectedAddressId, setSelectedAddressId] = useState(null);
  const [selectedAddress, setSelectedAddress] = useState(null);

  const fetchAddresses = async () => {
    try {
      dispatch(startLoading());
      const response = await axios.get(
        `http://localhost:8080/api/public/shippingAddress/getAll/${userId}`
      );
      if (response.data.length === 1) {
        setAddresses(response.data);
        setSelectedAddressId(response.data[0].id); // Set the first address as default
        setSelectedAddress(response.data[0]);// Automatically set the id
      }
      setAddresses(response.data);

      console.log(response.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      dispatch(stopLoading());
    }
  };

  useEffect(() => {
    fetchAddresses();
  }, []);


  const handleAddressChange = (addressId) => {
    console.log(addressId);
    const selected = addresses.find((address) => address.id === parseInt(addressId));
    console.log(selected);

    setSelectedAddress(selected);
    setSelectedAddressId(addressId);
  };
  const handleAddNewAddress = () => {
    setIsFormVisible(true);
  };

  //card data

  const searchParams = useSearchParams();
  const cartId = searchParams.get("cartId");
  const [cartItems, setCartItems] = useState([]);
  console.log("userId", userId);

  // Fetch Cart Items
  useEffect(() => {
    const fetchCartData = async () => {
      dispatch(stopLoading());
      try {
        const response = await axios.get(`http://localhost:8080/cart/getAll?userId=${userId}`);
        setCartItems(response.data);
        console.log("Fetched Cart Items:", response.data);
      } catch (err) {
        console.error("Failed to fetch cart items", err);
      } finally {
        dispatch(stopLoading());
      }
    };
    fetchCartData();
  }, []);


  // Calculate totals
  const calculateTotals = () => {
    let totalAmount = 0;
    let totalTax = 0;
    const shippingCharge = 10;

    const updatedItems = cartItems.map((item) => {
      const unitPrice = item.price;
      const quantity = item.quantity;
      const tax = unitPrice * 0.1;
      const subtotal = unitPrice * quantity + tax;

      totalTax += tax * quantity;
      totalAmount += subtotal + shippingCharge;

      return {
        productId: item.productId,
        productName: item.productName,
        unitPrice,
        quantity,
        tax,
        shippingCharge,
        subtotal,
      };
    });

    console.log("Transformed Items for Order:", updatedItems);
    console.log("Calculated Total Tax:", totalTax);
    console.log("Calculated Grand Total:", totalAmount);

    return { updatedItems, totalTax, totalAmount };
  };

  const { updatedItems, totalTax, totalAmount } = calculateTotals();

  // Handle Place Order
  const handlePlaceOrder = async () => {
    const { updatedItems, totalAmount } = calculateTotals();

    const orderPayload = updatedItems.map((item) => ({
      userId: userId,
      unitPrice: item.unitPrice,
      quantity: item.quantity,
      tax: item.tax,
      shippingCharge: item.shippingCharge,
      subtotal: item.subtotal,
      totalAmount: totalAmount,
      orderDate: new Date().toISOString(),
      // deliveryDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(), // 5 days
      deliveryDate: null,
      cancelled: false,
      returned: false,
      shippingAddressId: 1,
      productId: item.productId,
      orderStatusId: 1,
    }));
    dispatch(startLoading());
    try {
      // Place order
      console.log("Final Payload to API:", JSON.stringify(orderPayload, null, 2));
      const orderResponse = await axios.post(
        "http://localhost:8080/api/orders/add",
        orderPayload
      );

      console.log("Order placed successfully:", orderResponse.data);
      alert("Order placed successfully!");

      // Clear all items from the cart
      try {
        if (cartItems.length === 0) {
          console.log("No items in the cart to clear.");
          return;
        }

        console.log("Cart Items Before Deletion:", cartItems);

        await Promise.all(
          cartItems.map(async (item) => {
            if (!item.id) {
              console.warn(`Skipping item with missing cartId:`, item);
              return;
            }

            await axios.delete(
              `http://localhost:8080/cart/remove?userId=${userId}&cartId=${item.id}`
            );
            console.log(`Deleted cart item with ID: ${item.id}`);
          })
        );

        console.log("All cart items cleared successfully!");
        alert("Cart cleared successfully!");
        setCartItems([]);
      } catch (cartError) {
        console.error("Failed to clear cart:", cartError);
        alert("Order placed, but failed to clear cart.");
      }
    } catch (orderError) {
      console.error("Error placing order:", orderError);
      alert("Failed to place the order. Please try again.");
    } finally {
      dispatch(stopLoading());
    }
  };

  return (

    <div className="placeOrder">
      <div className="placeOrderContainer">
        <div className="placeOrderHead">
          <h2>Place Order</h2>
        </div>
        {!isFormVisible && (
          <>
            <div className="placeOrderContentMain">
              <div className="placeOrderContentHead">
                <h2>Shipping Address</h2>
                <button onClick={handleAddNewAddress}>Add New Address</button>
              </div>

              {addresses.length > 1 ? (
                <div className="placeOrderContent">
                  <label htmlFor="addressSelect">
                    <strong>Select Address:</strong>
                  </label>
                  <select
                    id="addressSelect"
                    className="addressDropdown"
                    value={selectedAddressId || ""}
                    onChange={(e) => handleAddressChange(e.target.value)}
                  >
                    <option value="" disabled>
                      Select an Address
                    </option>
                    {addresses.map((address) => (
                      <option key={address.id} value={address.id}>
                        {address.fullName} - {address.city}, {address.postalCode}
                      </option>
                    ))}
                  </select>
                </div>
              ) : addresses.length === 0 ? (
                <p>No Addresses Available, Please Add a New Address</p>
              ) : null}

              {selectedAddress && (
                <div>
                  {/* <h4>Shipping Address Details</h4> */}
                  <p>
                    <strong>Full Name:</strong> {selectedAddress.fullName}
                  </p>
                  <p>
                    <strong>Phone Number:</strong> {selectedAddress.phoneNumber}
                  </p>
                  <p>
                    <strong>Address Line 1:</strong> {selectedAddress.addressLine1}
                  </p>
                  <p>
                    <strong>Address Line 2:</strong> {selectedAddress.addressLine2}
                  </p>
                  <p>
                    <strong>City:</strong> {selectedAddress.city}
                  </p>
                  <p>
                    <strong>Postal Code:</strong> {selectedAddress.postalCode}
                  </p>
                </div>
              )}

            </div>
          </>
        )}

        {isFormVisible && (
          <form className="placeOrderForm" onSubmit={handleSubmit}>
            <div className={`formGroup ${errors.fullName ? "errorGroup" : ""}`}>
              <label>Full Name</label>
              <input
                type="text"
                name="fullName"
                className={`inputField ${errors.fullName ? "inputError" : ""}`}
                value={formData.fullName}
                onChange={handleChange}
              />
            </div>

            <div
              className={`formGroup ${errors.phoneNumber ? "errorGroup" : ""}`}
            >
              <label>Phone Number</label>
              <input
                type="text"
                name="phoneNumber"
                className={`inputField ${errors.phoneNumber ? "inputError" : ""}`}
                maxLength={10} // Restrict length to 10 characters
                value={formData.phoneNumber}
                onChange={handleChange}
              />
            </div>

            <div
              className={`formGroup ${errors.addressLine1 ? "errorGroup" : ""}`}
            >
              <label>Address Line 1</label>
              <input
                type="text"
                name="addressLine1"
                className={`inputField ${errors.addressLine1 ? "inputError" : ""
                  }`}
                value={formData.addressLine1}
                onChange={handleChange}
              />
            </div>

            <div className="formGroup">
              <label>Address Line 2</label>
              <input
                type="text"
                name="addressLine2"
                className={`inputField ${errors.addressLine1 ? "inputError" : ""
                  }`}
                value={formData.addressLine2}
                onChange={handleChange}
              />
            </div>

            <div className={`formGroup ${errors.city ? "errorGroup" : ""}`}>
              <label>City</label>
              <input
                type="text"
                name="city"
                className={`inputField ${errors.city ? "inputError" : ""}`}
                value={formData.city}
                onChange={handleChange}
              />
            </div>

            <div
              className={`formGroup ${errors.postalCode ? "errorGroup" : ""}`}
            >
              <label>Postal Code</label>
              <input
                type="text"
                name="postalCode"
                className={`inputField ${errors.postalCode ? "inputError" : ""
                  }`}
                value={formData.postalCode}
                onChange={handleChange}
              />
            </div>

            <div
              className={`formGroup ${errors.countryId ? "errorGroup" : ""}`}
            >
              <label>Country</label>
              <select
                name="countryId"
                className={`selectField ${errors.countryId ? "inputError" : ""
                  }`}
                value={formData.countryId}
                onChange={handleChange}
              >
                <option value="">Select Country</option>
                {countries.map((country) => (
                  <option key={country.id} value={country.id}>
                    {country.countryName}
                  </option>
                ))}
              </select>
            </div>

            <div className={`formGroup ${errors.stateId ? "errorGroup" : ""}`}>
              <label>State</label>
              <select
                name="stateId"
                className={`selectField ${errors.stateId ? "inputError" : ""}`}
                value={formData.stateId}
                onChange={handleChange}
              >
                <option value="">Select State</option>
                {states.map((state) => (
                  <option key={state.id} value={state.id}>
                    {state.stateName}
                  </option>
                ))}
              </select>
            </div>

            <div className="formActions">
              <button type="button" onClick={handleCancel}>
                Cancel
              </button>
              <button type="submit">Add Addresss</button>
            </div>
          </form>
        )}
      </div>

      <div className="OrderContainer">
        <div className="orderContainerHead">
          <h2>Place Your Order</h2>
          <div className="orderContainerContent">
            {cartItems.length > 0 ? (
              <table className="place-cart-items">
                <thead>
                  <tr>
                    <th>Product Image</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Tax</th>
                    <th>Quantity</th>
                  </tr>
                </thead>
                <tbody>
                  {updatedItems.map((item, index) => (
                    <tr key={index}>
                      <td className="place-image-column">
                        <img src="/image/tap-1.png" alt="product" />
                      </td>
                      <td className="place-details-column">
                        {item.productName}
                      </td>
                      <td className="place-price-column">
                        {item.unitPrice.toFixed(2)}
                      </td>
                      <td>
                        {item.tax.toFixed(2)}
                      </td>
                      <td>
                        {item.quantity}
                      </td>
                    </tr>
                  ))}
                  <tr className="place-card-bottom">
                    <td colSpan="4">
                      Total: ₹ {totalAmount.toFixed(2)}
                    </td>
                  </tr>
                </tbody>
              </table>
            ) : (
              <p>No items in the cart.</p>
            )}
          </div>
          <div className="place-order-btn">
            <button className="update-btn" onClick={handlePlaceOrder}>
              Place Order
            </button>
          </div>
        </div>
      </div>
    </div>

  );
};

export default PlaceOrder;
