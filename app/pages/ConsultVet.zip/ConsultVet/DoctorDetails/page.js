"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";

const DoctorDetails = () => {
  const [doctor, setDoctor] = useState(null);
  const [availableSlots, setAvailableSlots] = useState([]);
  const [bookedSlots, setBookedSlots] = useState([]);
  const [currentDate, setCurrentDate] = useState("2025-01-13");
  const [selectedSlot, setSelectedSlot] = useState(""); // State to store the selected time slot
  const [appointmentStatus, setAppointmentStatus] = useState(""); // To display booking status

  const id = 1; // Static doctor id for now
  const userId = 11; // Example userId, replace as needed
  const petType = "Dog"; // Example pet type, replace as needed
  const appointmentReason = "General Checkup"; // Example reason

  const [appointmentData, setAppointmentData] = useState({
    id: 0,
    veterinarianId: 1, // Assuming this is set dynamically based on the doctor
    userId: userId, // Dynamic user ID
    petType: petType,
    appointmentReason: appointmentReason,
    appointmentRequestedDate: currentDate, // Set to selected date
    startTime: "", // Start time as a string (e.g., "10:30")
    createdDate: currentDate, // Date when the appointment was created
    status: "PENDING", // Default status
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setAppointmentData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const formatTime = (time) => {
    // Function to format the time to "HH:mm" (removing seconds)
    const formattedTime = time.split(":").slice(0, 2).join(":");
    return formattedTime;
  };

  const bookAppointment = async () => {
    // Prepare the data to match the required format
    const updatedAppointmentData = {
      ...appointmentData,
      startTime: selectedSlot, // Set startTime as the selected slot in "HH:mm" format
    };

    // Ensure that appointmentRequestedDate is in correct format (YYYY-MM-DD)
    const formattedDate = new Date(updatedAppointmentData.appointmentRequestedDate).toISOString().split('T')[0];
    updatedAppointmentData.appointmentRequestedDate = formattedDate;

    console.log("Request Payload:", JSON.stringify(updatedAppointmentData, null, 2)); // Log to confirm the payload
  
    try {
      const response = await fetch("http://localhost:8080/api/public/appointments/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedAppointmentData),
      });

      // Handle API response and errors
      if (!response.ok) {
        const errorResponse = await response.json(); // Parse the error response
        console.error("API Response Error:", errorResponse); // Log error details
        
        // Display an error message
        if (errorResponse && errorResponse.error) {
          setAppointmentStatus(`Error: ${errorResponse.error} - ${errorResponse.message || "Please check your input."}`);
        } else {
          setAppointmentStatus("An unexpected error occurred. Please try again.");
        }
        return;
      }

      // If successful, handle the response
      const responseData = await response.json();
      console.log("Appointment booked successfully:", responseData);
      setAppointmentStatus("Appointment booked successfully!");
    } catch (error) {
      console.error("Network or API error:", error); // Log any network errors
      setAppointmentStatus("A network error occurred. Please try again.");
    }
  };

  useEffect(() => {
    // Fetch doctor details first
    const fetchDoctorDetails = async () => {
      try {
        const response = await fetch(`http://localhost:8080/api/public/veterinarian/getOne/${id}`);
        const data = await response.json();
        if (data) {
          console.log("Doctor Details:", data); // Log doctor details
          setDoctor(data);
        }
      } catch (error) {
        console.error("Error fetching doctor details:", error);
      }
    };

    const fetchAvailableSlots = async () => {
      try {
        const response = await fetch(`http://localhost:8080/api/public/veterinarian/available-slots/1?curDate=${currentDate}`);
        const data = await response.json();
        console.log("Available Slots:", data); // Log available slots
        setAvailableSlots(data || []);
      } catch (error) {
        console.error("Error fetching available slots:", error);
      }
    };

    const fetchBookedSlots = async () => {
      try {
        const response = await fetch(`http://localhost:8080/api/public/veterinarian/booked-slots/1`);
        const data = await response.json();
        console.log("Booked Slots:", data); // Log booked slots
        setBookedSlots(data || []);
      } catch (error) {
        console.error("Error fetching booked slots:", error);
      }
    };

    fetchDoctorDetails();
    fetchAvailableSlots();
    fetchBookedSlots();
  }, [id, currentDate]);

  const today = new Date().toISOString().split("T")[0]; // Set the minimum date as today

  const handleSlotChange = (timeSlot) => {
    // Format the selected time slot to remove seconds
    const formattedTime = formatTime(timeSlot);
    setSelectedSlot(formattedTime); // Store the formatted time in "HH:mm" format
    setAppointmentData((prev) => ({
      ...prev,
      startTime: formattedTime, // Set startTime directly to the selected formatted time
    }));
  };

  if (!doctor || !availableSlots.length || !bookedSlots.length) {
    return <div>Loading...</div>;
  }

  return (
    <div className="doctor-section">
      <div className="doctor-details-banner">
        <div className="doctor-details-container">
          <div className="doctor-details-row">
            <div>
              <div className="doctor-details-head">
                <h2>Doctor Details</h2>
              </div>
              <div className="link-address">
                <Link href="/" legacyBehavior>
                  <a className="doctor-details-link">Home</a>
                </Link>
                <span> / </span>
                <a className="doctor-details-link">Doctor Details</a>
              </div>
            </div>
          </div>
        </div>

        <div className="doctor-about-container">
          <div className="doctor-about">
            <div className="doctor-about-img">
              <img src="/image/doctor.jpg" alt="Doctor" />
            </div>

            <div className="doctor-time-slot-container">
              <h4>Pick a time slot</h4>

              <div>
                <label htmlFor="date-picker">Select Date:</label>
                <input
                  type="date"
                  id="date-picker"
                  value={currentDate}
                  onChange={(e) => setCurrentDate(e.target.value)}
                  min={today} // Set the minimum date as today
                />
              </div>

              {availableSlots && availableSlots.length > 0 ? (
                availableSlots.map((timeSlot, index) => (
                  <div className="doctor-time-table" key={index}>
                    <div className="time-slots">
                      <div
                        className={`slots-col ${
                          bookedSlots.some((bookedSlot) => bookedSlot.startTime === timeSlot)
                            ? "booked"
                            : ""
                        }`}
                      >
                        {/* Radio button for selecting the time slot */}
                        <input
                          type="radio"
                          id={`slot-${index}`}
                          name="timeSlot"
                          value={timeSlot}
                          checked={selectedSlot === formatTime(timeSlot)}
                          onChange={() => handleSlotChange(timeSlot)} // Update selectedSlot with formatted time
                          disabled={bookedSlots.some((bookedSlot) => bookedSlot.startTime === timeSlot)} // Disable if booked
                        />
                        <label htmlFor={`slot-${index}`}>{formatTime(timeSlot)}</label>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div>No available slots found.</div>
              )}

              <button
                className="book-slot-button"
                disabled={!selectedSlot}
                onClick={bookAppointment} // Call the book appointment function on button click
              >
                Book Appointment
              </button>

              {appointmentStatus && <div className="appointment-status">{appointmentStatus}</div>}

              {appointmentStatus === "Appointment booked successfully!" && bookedSlots.length > 0 && (
                <div className="appointment-details">
                  <h4>Booked Appointment Details:</h4>
                  <p><strong>Date:</strong> {bookedSlots[bookedSlots.length - 1].appointmentRequestedDate}</p>
                  <p><strong>Start Time:</strong> {bookedSlots[bookedSlots.length - 1].startTime}</p>
                  <p><strong>Status:</strong> {bookedSlots[bookedSlots.length - 1].status}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="doctor-info-container">
        <h3>
          {doctor.userDTO.firstName} {doctor.userDTO.lastName}
        </h3>
        <p>
          <strong>University:</strong> {doctor.veterinarianDTO.education}
        </p>
        <p>
          <strong>Location:</strong> {doctor.veterinarianDTO.city}
        </p>
        <p>
          <strong>Specialization:</strong> {doctor.veterinarianDTO.animalType}
        </p>
        <p>
          <strong>Languages:</strong> {doctor.veterinarianDTO.language}
        </p>
      </div>
    </div>
  );
};

export default DoctorDetails;
