"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { IoLocationSharp } from "react-icons/io5";

const ConsultVet = () => {
  const router = useRouter();
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const handleChange = (id) => {
    router.push(`/pages/ConsultVet/DoctorDetails?id=${id}`); // Dynamic routing with doctor ID
  };

  useEffect(() => {
    const fetchVeterinarians = async () => {
      try {
        const response = await fetch(
          "http://localhost:8080/api/public/veterinarian/getAll"
        );
        if (!response.ok) {
          throw new Error("Failed to fetch veterinarian details.");
        }
        const data = await response.json();
        
        // Log the fetched data to the console for debugging
        console.log("Fetched Data:", data);
        
        setDoctors(data); // Use the data directly as received from the API
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchVeterinarians();
  }, []);

  return (
    <div className="consult-banner">
      {/* Hero Section */}
      <div className="consult-banner-container">
        <h1>Online Vet Consultation</h1>
      </div>

      {/* About Section */}
      <div className="consult-about-container">
        {loading && <p>Loading veterinarians...</p>}
        {error && <p className="error-message">{error}</p>}
        {!loading &&
          !error &&
          doctors.map((vet) => (
            <div
              className="consult-about-card"
              key={vet.veterinarianDTO.id}
              //onClick={() => handleChange(vet.veterinarianDTO.id)}
            >
              <div className="consult-about-img">
                <img
                  src={vet.veterinarianDTO.imageUrl || "/image/doctor.jpg"} 
                  alt={`About ${vet.userDTO.firstName} ${vet.userDTO.lastName}`}
                />
              </div>
              <div className="consult-about-texts">
                <div className="consult-about-para">
                  <h1 className="consult-name">
                    {vet.userDTO.firstName} {vet.userDTO.lastName}
                  </h1>
                  <h3 className="consult-university">{vet.veterinarianDTO.education}</h3>

                  <p>Year of Experience :{vet.veterinarianDTO.yearsOfExperience}</p>
                  
                  <p>Languages: {vet.veterinarianDTO.language}</p>

                  <p> Animal Type: {vet.veterinarianDTO.animalType}</p>

                  <p className="consult-location">
                    <IoLocationSharp /> {vet.veterinarianDTO.city}
                  </p>
                  <div className="consult-about-btn">
                  <button
                  onClick={() => handleChange(vet.veterinarianDTO.id)}
                  >Learn More</button>
                </div>
                </div>
                
                
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default ConsultVet;
